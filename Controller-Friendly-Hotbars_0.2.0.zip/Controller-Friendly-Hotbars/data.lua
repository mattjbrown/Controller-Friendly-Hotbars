data:extend{
    {
        type = "custom-input",
        name = "previous-quickbar-hotkey",
        key_sequence = "COMMA",
    }
}
data:extend{
	{
		type = "custom-input",
		name = "next-quickbar-hotkey",
		key_sequence = "PERIOD",
	}
}
data:extend{
	{
		type = "custom-input",
		name = "set-quickbar-from-cursor-stack",
		key_sequence = "SLASH",
	}
}
data:extend{
	{
		type = "custom-input",
		name = "clear-current-quickbar-slot",
		key_sequence = "BACKSLASH",
	}
}