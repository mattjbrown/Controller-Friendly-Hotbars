data:extend{
    {
        type = "custom-input",
        name = "previous-quickbar-hotkey",
        key_sequence = "COMMA",
    }
}
data:extend{
	{
		type = "custom-input",
		name = "next-quickbar-hotkey",
		key_sequence = "PERIOD",
	}
}
